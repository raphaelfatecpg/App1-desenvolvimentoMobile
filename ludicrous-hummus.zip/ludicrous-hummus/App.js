import React, { Component } from 'react';
import { View, StyleSheet, FlatList, Text,Switch,Button } from 'react-native';
import Slider from '@react-native-community/slider';
import {Picker} from '@react-native-picker/picker';

class App extends Component{


  constructor(props) {
    super(props);
    this.state = {
      feed:[
        {id: 1, nome: 'Joseffe', idade: 32, email: 'joseffe@gmail.com'},
       
      ]
    }
  }


  render(){
    return(
      
      <View style={styles.container}>
      <Text style={styles.h1}>abertura de conta</Text>
        <FlatList 
        data={this.state.feed}
        keyExtractor={(item) => item.id}
        renderItem={ ({item}) => <Pessoa data={item}/>}
        />
   

      </View>
    )
  }
}


const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  areaPessoa:{
    backgroundColor: '#222',
    height: 600,
    marginBottom: 15
  },
  textoPessoa:{
    color: '#FFF',
    fontSize: 20,
  },
  h1:{fontSize: 40,
    },
 h2:{fontSize: 20,
  color:'white',
    },
     h3:{fontSize: 20,
  color:'white',
    }



})


export default App;




class Pessoa extends Component{
   constructor(props) {
    super(props);
    this.state = {
      valor: 0,
       status: false
     

    
    }
  }

  clicou(){
    alert('Clicou aqui!');
  }


  render(){
    return(
      <View style={styles.areaPessoa}>
        <Text style={styles.textoPessoa}> Nome: {this.props.data.nome} </Text>
        <Text style={styles.textoPessoa}> Idade: {this.props.data.idade} </Text>
        
      <Slider
      minimumValue={0}
      maximumValue={5000}
      onValueChange={ (valorSelecionado) => this.setState({valor: valorSelecionado})}
      value={this.state.valor}
    />
    <Text style={styles.h2}>Limite:</Text>
    <Text style={styles.h2}>
      {this.state.valor.toFixed(0)}R$ 
    </Text>

    <Picker style={styles.h2}>
        <Picker.Item key={1} value={1} label="Masculino" />
        <Picker.Item key={2} value={2} label="Feminino" />
        
      </Picker> 
       <Picker style={styles.h2}>
        <Picker.Item key={3} value={1} label="Fundamental" />
        <Picker.Item key={4} value={2} label="Ensino Médio" />
        <Picker.Item key={5} value={2} label="Superior Incompleto" />
        <Picker.Item key={6} value={2} label="Superior Completo" />
      </Picker>

  <Text style={styles.h3}>
        {(this.state.status) ? " Sou Brasileiro" : "Não sou Brasileiro"}
      </Text>

      <Switch style={{textAlign:'left'}}
      value={this.state.status}
      onValueChange={ (valorSwitch) => this.setState({status: valorSwitch})}
      />

            <Button color='green' title='Confirmar' onPress={() => this.clicou()}/>

  

      </View>
    );
  }
}
