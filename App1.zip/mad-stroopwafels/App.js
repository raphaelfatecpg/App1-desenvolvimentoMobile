import React, { Component } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

function App() {
  return (
    <View>
      <Image
        style={{ margin: 30, width: 200, height: 200 }}
        source={require('./raphael.jpg')}
      />
      <Text style={styles.a}>
        Raphael Willian Cristovao dos Santos raphael.fatecpg@gmail.com
       </Text>
       <Text style={styles.a}>
        (13) 98181-6848
      </Text>
      <Text></Text>
      <Text style={styles.a}>
        Formação: Analise e desenvolvimento de sistemas
      </Text>
      <Text></Text>
      <Text style={styles.a}>
        Projetos: Desenvolvimento de HeadShop online com html, css, javascript e
        php com banco MySQL
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  a: {
    fontSize: 20,
    alignSelf: 'center',
  },
});

export default App;
